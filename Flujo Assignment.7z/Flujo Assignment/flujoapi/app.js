var express = require('express');
var path = require('path');
var fs = require('fs')
var promise = require('bluebird');
var options = { promiseLib: promise };
var pgp = require('pg-promise')(options);

var bodyparser = require('body-parser');

var app = new express();
var cs = "postgres://postgres:root@localhost:5432/Flujo";
var db = pgp(cs);


app.use(express.static(path.join(__dirname,'./public')));
app.use(bodyparser.urlencoded({ extended: true, limit:'500mb' }));
app.use(bodyparser.json({ extended: true, limit:'500mb' }));

app.all("*", function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Cache-Control, Pragma, Origin, Authorization, Content-Type, X-Requested-With");
    res.header("Access-Control-Allow-Methods", "*");
    return next();
});

app.post('/insert', (req, res, next) => {
  
    var uname = req.body.usr.userName;
    var fname = req.body.usr.firstName;
    var lname = req.body.usr.lastName;
    var em = req.body.usr.emailId;
    var pn = req.body.usr.phoneNumber;
    var add1 = req.body.usr.address1;
    var add2 = req.body.usr.address2;
    var img = req.body.usr.image;

    var pt = '';
    var dt = new Date();
    //console.log(req.body)
    ptr = dt.getFullYear() +""+ dt.getMonth()+"" + dt.getMilliseconds()+'.png';
    pts = './public/'+ ptr;
     fs.writeFile(pts, img,'base64', (err) => {
        if(err)
        console.log(err)
        else{
            console.log('Image Svaed Success...');
        }
    });

    ptr = 'http://localhost:3400/'+ptr;
    

    db.any('select * from fn_adduser($1,$2,$3,$4,$5,$6,$7,$8)', [uname, fname, lname, em, pn, add1, add2,ptr]).then((data) => {
        console.log('Record Inserted...')
        res.status(200).send(data);
    })
})



app.get('/get', (req, res, next) => {

    db.any('select * from fn_getalluserdetails()').then((data) => {
        res.status(200).send(data);
    })
})
app.get('/getbyid/:id', (req, res, next) => {
    var i = parseInt(req.params.id);
    db.any('select * from fn_getbyid($1)', i).then((data) => {

        res.status(200).send(data);
    })
})
app.put('/update', (req, res, next) => {
    var uname = req.body.userName;
    var fname = req.body.firstName;
    var lname = req.body.lastName;
    var emid = req.body.emailId;
    var pno = req.body.phoneNumber;
    var add1 = req.body.address1;
    var add2 = req.body.address2;
    var img = req.body.image;
    var i = req.body.id;
    db.any('select * from fn_updateuser($1,$2,$3,$4,$5,$6,$7,$8,$9) ',  [i, uname, fname,lname,emid,pno,add1,add2,img]).then((data) => {
        res.send(data);
        console.log(data);
        console.log( db.any('select * from fn_updateuser($1,$2,$3,$4,$5,$6,$7,$8,$9) ',  [i, uname, fname,lname,emid,pno,add1,add2,img]))

    })
})

app.delete('/delete/:id', (req, res, next) => {
    var i = parseInt(req.params.id);
    db.any('delete from userdetails where id=$1', i).then((data) => {

        res.status(200).send(data);
    })
})

app.listen(3400, (err) => {
    if (err) {
        console.log('Server cannot Start....error....');
    }
    else {
        console.log('server Started at : http://localhost:3400')
    }
})


