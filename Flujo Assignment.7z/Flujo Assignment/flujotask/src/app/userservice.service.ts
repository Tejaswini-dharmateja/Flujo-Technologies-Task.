import { Injectable } from '@angular/core';
import{observable, Observable} from 'rxjs';
import {HttpClient,HttpClientModule, HttpHeaders} from '@angular/common/http';
import { user } from 'src/model/user';
//import {user} from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {

  httpOptions= {headers:new HttpHeaders({
    'Content-Type':'application/json'
  }) };

  myUrl='http://localhost:3400'

  constructor(private http:HttpClient) { }

  saveAddfrm(usr)
  { 
    debugger
    return this.http.post(this.myUrl+'/insert',{usr},this.httpOptions)
  }
  getallUsers():Observable<any>{
    return this.http.get(this.myUrl + '/get',{responseType:'json'})

  }

  getByIds(id:number):Observable<any>
  {
    return this.http.get(this.myUrl+'/getbyid/'+ id,{responseType: 'json'})
  }

  deletebyId(id:number):Observable<any>
  {
    return this.http.delete(this.myUrl+'/delete/'+ id,{responseType: 'json'})
  }

  updateUser(usr:user): any {
    return this.http.put(this.myUrl+'/update/' ,usr,this.httpOptions) ;
   }

   editById(id:number): Observable<any>{
    return this.http.get(this.myUrl)

  }
}
