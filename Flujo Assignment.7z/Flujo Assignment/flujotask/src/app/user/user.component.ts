import { Component, OnInit, ViewChild } from '@angular/core';
import { user } from 'src/model/user';
import { UserserviceService } from '../userservice.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  @ViewChild("frm") myForm;
  usr: user;
  List: any;
  data: any;
  list1: any;
  url: any;



  constructor(private userser: UserserviceService) {
    this.usr = new user();
  }


  onSelectFile(event) {
    if (event.target.files && event.target.files[0]) {
      var reader = new FileReader();
      reader.readAsDataURL(event.target.files[0]); // read file as data url
      reader.onload = (ev: any) => { // called once readAsDataURL is completed
        this.url = ev.target.result;
        this.usr.image = reader.result;
      }
    }
  }


  addForm() {
    this.usr.image = this.usr.image.replace("data:image/gif;base64,", "");
    this.usr.image = this.usr.image.replace("data:image/jpeg;base64,", "");
    this.userser.saveAddfrm(this.usr).subscribe((data) => {
      if(data){
        document.getElementById('close').click();
        Swal.fire('Added Sucessfully');
        this.getAll();
      }
    })
  }


  getAll() {
    this.userser.getallUsers().subscribe((data) => {
      this.List = data;
      console.log(data)
    })
  }

  userDetails(id) {
    this.userser.getByIds(id).subscribe((data) => {
      this.list1 = data;
    });
  };

  editUserDetails(id: number) {
    this.userser.getByIds(id).subscribe((data) => {
      this.usr.id = data[0].uid;
      this.usr.userName = data[0].uname;
      this.usr.firstName = data[0].fname;
      this.usr.lastName = data[0].lname;
      this.usr.emailId = data[0].email_id;
      this.usr.phoneNumber = data[0].phnumber;
      this.usr.address1 = data[0].addr1;
      this.usr.address2 = data[0].add2;
      this.usr.image = data[0].img;
    });
  };

  updateDetails() {
    this.usr.image = this.usr.image.replace("data:image/gif;base64,", "");
    this.usr.image = this.usr.image.replace("data:image/jpeg;base64,", "");
    this.userser.updateUser(this.usr).subscribe((data) => {
      if (data) {
        Swal.fire('Updated Sucessfully');
        this.getAll();
        document.getElementById('close').click();
      };
    });
  };

delete(id:number){
     this.userser.deletebyId(id).subscribe((data)=>
     {
       this.List=data;
       Swal.fire('Deleted Sucessfully');
       this.getAll();
     })
  }



  ngOnInit() {
    this.getAll();
  }
  resetForm() {
    this.myForm.reset();
    this.usr.id= null;
  }
}
