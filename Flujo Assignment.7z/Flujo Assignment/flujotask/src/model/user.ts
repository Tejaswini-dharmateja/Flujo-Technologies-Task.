export class user
{
id:number;
userName:string;
firstName:string;
lastName:string;
emailId:any;
phoneNumber:any;
address1:any;
address2:any;
image:any;
}